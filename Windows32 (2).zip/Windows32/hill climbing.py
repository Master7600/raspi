import math

inc = 0.1
sp = [1,1]
p1 = [1,5]
p2 = [6,4]
p3 = [5,2]
p4 = [2,1]

def Distance(x1, y1, x2, y2):
    return math.pow(x2-x1, 2) + math.pow(y2-y1, 2)

def Sum_of_Distances(x1, y1, px1, py1, px2, py2, px3, py3, px4, py4):
    return (Distance(x1, y1, px1, py1)+Distance(x1, y1, px2, py2)+Distance(x1, y1, px3, py3)+Distance(x1, y1, px4, py4))

def New_Distance(x1, y1, p1, p2, p3, p4):
    d1 = [x1, y1]
    d1.append(Sum_of_Distances(x1, y1, p1[0], p1[1], p2[0], p2[1], p3[0], p3[1], p4[0], p4[1]))
    return d1

Min_Distance = Sum_of_Distances(sp[0], sp[1], p1[0], p1[1], p2[0],p2[1], p3[0], p3[1], p4[0], p4[1])
flag = True

def New_Points(minimum, d1, d2, d3, d4):
    if d1[2] == minimum:
        return [d1[0], d1[1]]
    elif d2[2] == minimum:
        return [d2[0], d2[1]]
    elif d3[2] == minimum:
        return [d3[0], d3[1]]
    elif d4[2] == minimum:
        return [d4[0], d4[1]]

i = 1
while flag:
    d1 = New_Distance(sp[0]+inc, sp[1], p1, p2, p3, p4)
    d2 = New_Distance(sp[0]-inc, sp[1], p1, p2, p3, p4)
    d3 = New_Distance(sp[0], sp[1]+inc, p1, p2, p3, p4)
    d4 = New_Distance(sp[0], sp[1]-inc, p1, p2, p3, p4)
    print (i,' ', round(sp[0], 2), round(sp[1], 2))
    minimum = min(d1[2], d2[2], d3[2], d4[2])
    if minimum < Min_Distance:
        sp = New_Points(minimum, d1, d2, d3, d4)
        Min_Distance = minimum
        i+=1
    else:
        flag = False
