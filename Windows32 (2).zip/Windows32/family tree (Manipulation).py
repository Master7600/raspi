A="Dada Dadi"
B="Nana Nani"
C="Papa"
D="Uncle Aunty"
E="Mummy"
F="Me"
G="behen"
H="Cousin"
def tree():
    if(A=="Dada Dadi"):
        if(B=="Nana Nani"):
            print(A,"------",B)
        else:
            print(A)

    if(C=="Papa"):
        if(E=="Mummy"):
            if(D=="Uncle Aunty"):
                print("|                |        |")
                print(E,"         ",C,"---",D)
                print("|                |          |")
                print("----------------------------|")
                print("        |                   |")
    if(F=="Me"):
        if(G=="behen"):
            if(H=="Cousin"):
                print(F,"-----------",G,"-----",H)


tree() 
